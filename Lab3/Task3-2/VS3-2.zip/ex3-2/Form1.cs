﻿using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace ex3_2 // 請確認這裡與你的專案名稱一致
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                serialPort1.PortName = "COM3"; // 請確認為你的 Arduino COM 埠
                serialPort1.BaudRate = 9600;

                // 綁定「收到 Arduino 傳來資料時」要自動觸發的函式
                serialPort1.DataReceived += SerialPort1_DataReceived;

                serialPort1.Open();
                label1.Text = "當前狀態：Waiting for button...";
            }
            catch (Exception ex)
            {
                label1.Text = "連線失敗：" + ex.Message;
            }
        }

        // 當 Arduino 按下實體按鈕傳來字串時，會自動執行這裡
        private void SerialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                // 讀取 Arduino 用 Serial.println 傳過來的一整行文字
                string incomingText = serialPort1.ReadLine().Trim();

                // 安全地跨執行緒更新視窗上的 label1 文字
                this.Invoke(new Action(() =>
                {
                    label1.Text = "按鈕狀態: " + incomingText;
                }));
            }
            catch { }
        }

        // 視窗上的 On 按鈕：控制 Arduino LED 亮起
        private void button1_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Write("1");
            }
        }

        // 視窗上的 Off 按鈕：控制 Arduino LED 熄滅
        private void button2_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Write("0");
            }
        }
    }
}